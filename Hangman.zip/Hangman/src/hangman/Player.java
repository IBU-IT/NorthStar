package hangman;
import java.awt.Graphics;
// player in the game can be represented here as the letters ( if it's having art )
public class Player extends GameObject {

	public Player(int x, int y, ID id) {
		super(x, y, id);
	}
	/* we can use the getters and setters here since they are basically
	 * in this class but hidden*/

	// code here the tick and render methods we made in the GmeObject class
	public void tick() {
		
	}
	
	public void render(Graphics g) {
		
	}
	
}
