package hangman;
/* in order to separate the objects we can ID them here 
 * I put some default examples in but Muhamed can change  and categorize that
 * based on what he drew ( if we won't do letters as objects then delete it
 * and such ...
 */
public enum ID {

	guillotine_parts(),
	body_parts(),
	letters();
	// and so on
}